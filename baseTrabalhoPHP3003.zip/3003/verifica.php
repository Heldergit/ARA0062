<?php
session_start();

$login = $_POST["login"];
$senha = $_POST["senha"];

include_once ("../servico/Bd.php");

$bd = new Bd();
$sql = "select * from trabalho_3003 where login = '$login' and senha = '$senha'";

//
//Nao proteje contra sql injection
//
foreach($bd->query($sql) as $row) {
    $_SESSION["autenticado"]=true;
    $_SESSION["idusuario"]=$row['id'];
    $_SESSION["loginusuario"]=$row['login'];

    $html ="
    <html>
        <head> <title> Página de verificação </title></head>
        <body>
    
           <script>
    window.location.replace('https://fourth-pots.000webhostapp.com/3003/menu.php');
           </script>
      
        </body>
    </html>
    
    ";
   
    echo $html;
    return;
}
//se a consulta retornar vazia, nem entra no foreach
//e o usuário digitou os dados incorretos.
    session_destroy ( ) ;
    $html ="
<!doctype>
<html>
    <head> <title> Página de verificação </title></head>
    <body>

        <h1>Seu login: $login e sua senha = $senha SÃO INVÁLIDOS</h1>
  
    </body>
</html>

";

echo $html;
?>
