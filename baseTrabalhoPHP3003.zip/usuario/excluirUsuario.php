<?php
include_once("../servico/Bd.php");

$bd = new Bd();

$id = $_GET['id'];

$sql = "delete from trabalho_3003 where id = '$id'";

$contador = $bd->exec($sql);

echo "<h1> $contador Usuário foi removido </h1>";
echo "<a href='consultaUsuario.php'> < Voltar</a>";

?>