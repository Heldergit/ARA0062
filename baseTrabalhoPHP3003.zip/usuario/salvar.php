<?php

include_once ("../servico/Bd.php");

$login = $_GET["login"];
$senha = $_GET["senha"];

if (isset($_GET["id"])) { //atualiza
    $id = $_GET["id"];
    $sql = "update trabalho_3003 set login='$login',  senha='$senha' where id='$id' ";
}else { //inclui
    $sql = "INSERT INTO `trabalho_3003` (`id`, `login`, `senha`) VALUES (NULL, '$login', '$senha')";    
}


$bd = new Bd();
$contador = $bd->exec($sql); // insert, update e delete

echo "<h1> Foi incluído/atualizado $contador registro </h1>";

echo "<a href='consultaUsuario.php'>Voltar </a>";

?>